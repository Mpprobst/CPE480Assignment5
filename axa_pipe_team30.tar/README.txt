This is a repository for Assignment 3: Pipelined AXA

Files in this repository include:
1. axa.aik - axa instruction encoding
2. axa.v - pipelined axa verilog design
3. axa_debugged.v - verilog design with $display commands used for debugging.
4. ImplementorsNotes.pdf
